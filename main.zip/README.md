# Portfolio — Full 3D Animated Website

Ek **ready-to-use personal portfolio website** — full-page Three.js 3D background, scroll-reactive gradient shapes, 3D tilt project cards, custom cursor, aur smooth scroll-reveal animations ke sath. Koi framework nahi, koi backend nahi — sirf HTML, CSS aur JavaScript.

## 📁 Folder Structure

```
portfolio-website/
├── index.html            → Page ka structure
├── css/
│   └── style.css         → Saari styling, colors, animations
├── js/
│   ├── three-scene.js    → Background ka 3D scene (Three.js)
│   └── main.js           → UI logic: nav, cursor, reveal, tilt cards, data render
├── data/
│   └── data.js            → Aapka tamam CONTENT (naam, bio, skills, projects, contact)
└── README.md              → Yehi file
```

## ✏️ Apna Content Daalna (Sabse Important Step)

Poori website ka text **`data/data.js`** file se aata hai. Bas wahi file kholein aur har field ko apne content se replace kar dein:

- `hero` → apna naam, tagline, intro line
- `about` → apni bio aur stats (projects/years/clients)
- `skills` → apni skills, groups mein
- `work` → apne projects (title, description, tags, link)
- `contact` → apna email, location, social links

Misaal:

```js
hero: {
    eyebrow: "Creative Technologist",   // ← apni designation likhein
    name: "Zara Malik",                  // ← apna naam likhein
    ...
}
```

`index.html` ya CSS/JS files ko chhedne ki **zaroorat nahi** — sirf `data.js` edit karein, save karein, browser refresh karein.

## 🎨 Design Kaisi Hai

- **Theme:** Dark background, multi-color gradient accents (coral → violet → aqua → gold) — jo bhi gradient text/buttons mein dikhta hai wahi gradient 3D shapes ki lighting mein bhi use hota hai, taake poori site ek hi "identity" feel de.
- **3D:** Background mein ek continuous Three.js scene chal rahi hai — har section ke peeche ek alag gradient-lit low-poly shape hai, jo scroll karne par parallax ke sath move karti hai aur mouse move par halka sa tilt karti hai.
- **Interaction:** Project cards par mouse le jaane se card khud 3D mein tilt karta hai (real-time perspective tilt).
- **Fonts:** Space Grotesk (headings), Inter (body text), JetBrains Mono (labels/eyebrows).

## ▶️ Kaise Chalayein

1. Pura `portfolio-website` folder save karein (sab files apni jagah par rahein).
2. `index.html` ko double-click karke browser mein khol lein.
3. Internet connection chahiye hoga (Google Fonts aur Three.js library CDN se load hoti hain) — agar offline use karna ho to mujhe bataiye, main fonts/library local bhi daal sakta hoon.

## 🌐 Online Daalna (Deploy)

Ye static site hai, isliye kahin bhi free host ho sakti hai:
- **GitHub Pages** — repo bana kar push karein, Pages enable karein
- **Netlify / Vercel** — folder ko drag-and-drop karein
- Koi bhi normal shared hosting jahan aap files upload kar sakein

## ⚙️ Performance & Accessibility Notes

- 3D animation `prefers-reduced-motion` ko respect karti hai (jin users ne reduced motion on rakha hai, unke liye halki si static version chalti hai).
- Tab minimize/hide hone par 3D animation pause ho jaati hai (battery/CPU bachane ke liye).
- Mobile par custom cursor aur tilt-effect automatically off ho jaate hain (touch devices ke liye zaroori nahi).

## 🛠️ Technologies

- HTML5 + CSS3 (Grid, Flexbox, custom properties, animations)
- Vanilla JavaScript (IntersectionObserver, requestAnimationFrame)
- [Three.js](https://threejs.org/) r128 (CDN se, koi installation nahi chahiye)
- Google Fonts
